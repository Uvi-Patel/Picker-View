//
//  ViewController.swift
//  Picker view
//
//  Created by MAC on 25/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
   

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var imgView: UIImageView!
    
//    var arr = ["whatsapp","facebook","instagram","google","twitter"]

//    var arr = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
//
//    var arr1 = ["Apple","Ball","Cat","Dog","Elephant","Fan","Gan","Hen","Iphon","Joker","Kite","Lion","Monkey","Nife","Ox","Perrot","Queen","Ring","Sun","Tiger","Umbrella","Ven","Window","X-rey","Yaak","Zebra"]
   // var year = [""]
    var year = [String]()
    var month = [String]()
    var date = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        for i in stride(from: 2000, to: 2022, by:1)
//        {
//            print("\(i)")
//        }
        
        for y in 2000...2021
        {
            print("\(y)")
            let str = String(y)
            year.append(str)

        }
        
        for m in 1...12
        {
            print("\(m)")
            let str = String(m)
            month.append(str)

        }
        
        for d in 1...31
        {
            print("\(d)")
            let str = String(d)
            date.append(str)

        }
        imgView.layer.cornerRadius = 120
        textField.isEnabled = false
//        textField.isHidden = true

        pickerView.dataSource = self
        pickerView.delegate = self
//        pickerView.numberOfRows(inComponent: year.count)
//        pickerView.numberOfRows(inComponent: month.count)
//        pickerView.numberOfRows(inComponent: date.count)
//        pickerView.showsSelectionIndicator = false
//        pickerView.selectRow(20, inComponent: 0, animated: true)
//        pickerView.reloadComponent(0)
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
           return 3
       }
       
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//        if (component == 0)
//        {
//            return arr.count
//        }
//        else
//        {
//            return arr1.count
//        }
//        return arr.count
        if component == 0
        {
            return year.count
        }
        else if component == 1
        {
            return month.count
        }
        else
        {
            return date.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        print("titleForRow")
//        if (component == 0)
//        {
//            return arr[row]
//        }
//        else
//        {
//            return arr1[row]
//        }
//        return arr[row]
        if component == 0
        {
            return year[row]
        }
        else  if component == 1
        {
            return month[row]
        }
        else
        {
            return date[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print("didSelectRow")
//        self.textField.text = arr[row] + " For " + arr1[row]
//        textField.text = arr[row]
//        imgView.image = UIImage(named: arr[row])
        let yy = year[pickerView.selectedRow(inComponent: 0)]
        let mm = month[pickerView.selectedRow(inComponent: 1)]
        let dd = date[pickerView.selectedRow(inComponent: 2)]
        
        textField.text = "\(yy) - \(mm) - \(dd)"
//        textField.text = year[row] + " - " + month[row] + " - " + date[row]
  
 /*       if component == 0
        {
            textField.text = year[row]
        }
        else if component == 1
        {
            textField.text = month[row]
        }
        else
        {
            textField.text = date[row]
        }*/
        
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        print("rowHeightForComponent")
        return 50
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 100
    }
 
}

